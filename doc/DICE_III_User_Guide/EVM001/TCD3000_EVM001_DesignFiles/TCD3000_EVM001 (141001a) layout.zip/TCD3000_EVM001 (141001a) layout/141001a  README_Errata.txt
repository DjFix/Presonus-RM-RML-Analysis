The 141001a layout does not include a recommended change that was made to the schematics. In the version (5-11-2015 4-03-42 PM) schematics, diode D4 is added to the reset circuit.
